import { Component, OnInit , ViewChild} from '@angular/core';
import { Router } from '@angular/router';
import { MatTable } from '@angular/material';
import { MatPaginator } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { PopupComponent } from '../popup/popup.component';

@Component({
  selector: 'app-curd',
  templateUrl: './curd.component.html',
  styleUrls: ['./curd.component.css']
})

export class CurdComponent implements OnInit {

  registerDetails;
  Editdetails;
  ind;
  Editted;
  @ViewChild(MatTable,{static:false}) table: MatTable<any>;
  @ViewChild(MatPaginator,{static:true}) paginator: MatPaginator;


  constructor(public router:Router, public dialog: MatDialog) { 
   
  }

  ngOnInit() {
    this.registerDetails = JSON.parse(localStorage.getItem('details'));
    if(localStorage.getItem('edit')!=null){
      this.Editted = JSON.parse(localStorage.getItem('edit'));
      this.ind = JSON.parse(localStorage.getItem('index'));
      localStorage.removeItem('edit')
    console.log(this.ind);

    for(var i=0; i<=this.registerDetails.length-1; i++){
      if(i==this.ind){
        this.registerDetails[i] = this.Editted;
        console.log(this.registerDetails)
        localStorage.setItem('details',JSON.stringify(this.registerDetails));

        // return (this.registerDetails);
      }
    }
  }

    // console.dir(typeof(this.registerDetails));
    // localStorage.clear();
    // console.log(JSON.parse(localStorage.getItem('edit')))
  }
  headSection:string[] = ['firstname','lastname','gender','mobile','email','password','actions']; 
  // dataSource = this.registerDetails;

  registerEdit(element: any, i: any){
   this.Editdetails = element;
   this.ind = i;
    console.log(this.ind)
    localStorage.setItem('edit', JSON.stringify(this.Editdetails));
    localStorage.setItem('index',JSON.stringify(this.ind));
    this.router.navigate(['edit']);
    
  }
  // updateTable(){
  //   this.Editted = JSON.parse(localStorage.getItem('edit'));
  //   this.ind = JSON.parse(localStorage.getItem('index'));
  //   console.log(this.ind);

  //   for(var i=0; i<=this.registerDetails.length-1; i++){
  //     if(i==this.ind){
  //       this.registerDetails[i] = this.Editted;
  //       console.log(this.registerDetails)
  //       localStorage.setItem('details',JSON.stringify(this.registerDetails));
  //       this.table.renderRows();

  //       // return (this.registerDetails);
  //     }
  //   }

  // }

  registerDelete(element: any, i: any){
    const dialogRef = this.dialog.open(PopupComponent, {
      width: '250px'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
      result;
      if(result == 'yes'){
        this.ind = i;
      this.registerDetails.splice(i,1);
      localStorage.setItem('details',JSON.stringify(this.registerDetails));
      this.table.renderRows();
      }
      else{
        return;
      }

    });
    
      

  }
  // clearTable(){
  //   localStorage.clear();
  // }
}
  
