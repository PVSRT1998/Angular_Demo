import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  editForm: FormGroup;
  editFormSubmit = null;
  editFormUpdate;
  constructor(public formbuilder:FormBuilder, public router:Router) { 
    // console.dir(this.registerForm);
  }

  

  ngOnInit() {
    this.editForm = this.formbuilder.group({

      firstname:[,Validators.required],
      lastname:[,Validators.required],
      gender:[,Validators.required],
      mobile:[,[Validators.required,Validators.pattern('[0-9]{10}')]],
      email:[,[Validators.required,Validators.email]],
      password:[,[Validators.required,Validators.minLength(8)]],
      confirmpassword:[,Validators.required]
  
    });
    console.log(JSON.parse(localStorage.getItem('edit')));

    this.editForm.setValue(JSON.parse(localStorage.getItem('edit')));
    // console.log(this.editForm)
  }

  get editFormControl(){
    return this.editForm.controls
  }
  update(){
    this.editFormSubmit = true;
    if(this.editForm.invalid){
      return;
    }
    localStorage.setItem('edit',JSON.stringify(this.editForm.value));
    console.log(this.editForm.value);
    this.router.navigate(['curd']);
    this.editForm.reset();
  }
}
