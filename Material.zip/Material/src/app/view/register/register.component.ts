import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerFormSubmit = null;

  registerFormDetails =[];
  constructor(public formbuilder:FormBuilder, public router:Router) { }

  registerForm = this.formbuilder.group({
    
    firstname:['',Validators.required],
    lastname:['',Validators.required],
    gender:['',Validators.required],
    mobile:['',[Validators.required,Validators.pattern('[0-9]{10}')]],
    email:['',[Validators.required,Validators.email]],
    password:['',[Validators.required,Validators.minLength(8)]],
    confirmpassword:['',Validators.required]
  });

  ngOnInit() {
  }
  get registerFormControl() {
    return this.registerForm.controls;
  }

  register(){

    this.registerFormSubmit = true;
    if (this.registerForm.invalid) {
      return;
   }
    // this.registerFormSubmit = false;
    if(JSON.parse(localStorage.getItem('details')) != null){
      this.registerFormDetails = JSON.parse(localStorage.getItem('details'));

    }
    console.dir(JSON.parse(localStorage.getItem('details')));
    console.log(this.registerForm);
    this.registerFormDetails.push(this.registerForm.value);
    localStorage.setItem('details', JSON.stringify(this.registerFormDetails));
    this.router.navigate(['curd']);
    this.registerForm.reset();
  }
}
