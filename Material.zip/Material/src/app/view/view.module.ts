import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ViewRoutingModule } from './view-routing.module';
import { ViewComponent } from './view.component';
import { MaterialModule } from '../material.module';
import { RegisterComponent } from './register/register.component';
import { CurdComponent } from './curd/curd.component';
import { EditComponent } from './edit/edit.component';
import { PopupComponent } from './popup/popup.component';


@NgModule({
  declarations: [ViewComponent, RegisterComponent, CurdComponent, EditComponent, PopupComponent ],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule,
    MaterialModule,
    ViewRoutingModule
  ],
  entryComponents: [
    PopupComponent
  ]
})
export class ViewModule { }
